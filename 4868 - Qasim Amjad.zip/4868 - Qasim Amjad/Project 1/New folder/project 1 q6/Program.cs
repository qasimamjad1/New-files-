﻿using System;
using System.Linq;

class Program
{
    static void Main()
    {
        Console.WriteLine("Vowel/Consonant Counter");
        Console.WriteLine("Enter a sentence:");
        string sentence = Console.ReadLine();

        string[] words = sentence.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

        Console.WriteLine("Vowels and Consonants Count:");
        foreach (string word in words)
        {
            int vowelCount = CountVowels(word);
            int consonantCount = CountConsonants(word);

            Console.WriteLine("\"" + word + "\": " + vowelCount + " vowel(s) and " + consonantCount + " consonant(s)");
        }

        Console.ReadKey();
    }

    static int CountVowels(string word)
    {
        int count = 0;
        string vowels = "aeiou";

        foreach (char c in word.ToLower())
        {
            if (vowels.Contains(c))
            {
                count++;
            }
        }

        return count;
    }

    static int CountConsonants(string word)
    {
        int count = 0;
        string consonants = "bcdfghjklmnpqrstvwxyz";

        foreach (char c in word.ToLower())
        {
            if (consonants.Contains(c))
            {
                count++;
            }
        }

        return count;
    }
}
