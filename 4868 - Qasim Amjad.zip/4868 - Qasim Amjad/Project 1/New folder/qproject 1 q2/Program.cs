﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main()
    {
        Console.WriteLine("Word Frequency Analysis");
        Console.WriteLine("Enter a sentence:");
        string sentence = Console.ReadLine();

        Dictionary<string, int> wordFrequency = GetWordFrequency(sentence);

        Console.WriteLine("\nWord Frequency:");
        foreach (KeyValuePair<string, int> pair in wordFrequency)
        {
            Console.WriteLine("\"" + pair.Key + "\": " + pair.Value);
        }

        Console.WriteLine("\nSentence Maker");
        Console.WriteLine("Enter a number 'N':");
        int n = Convert.ToInt32(Console.ReadLine());

        List<string> words = wordFrequency.Keys.ToList();

        Console.WriteLine("\nGenerated Sentences:");
        for (int i = 1; i <= n; i++)
        {
            string sentenceResult = GenerateSentence(words);
            Console.WriteLine(i + ". " + sentenceResult);
        }

        Console.ReadKey();
    }

    static Dictionary<string, int> GetWordFrequency(string sentence)
    {
        string[] words = sentence.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

        Dictionary<string, int> wordFrequency = new Dictionary<string, int>();

        foreach (string word in words)
        {
            if (wordFrequency.ContainsKey(word))
            {
                wordFrequency[word]++;
            }
            else
            {
                wordFrequency[word] = 1;
            }
        }

        return wordFrequency;
    }

    static string GenerateSentence(List<string> words)
    {
        Random random = new Random();
        string sentence = "";

        for (int i = 0; i < 5; i++)
        {
            int randomIndex = random.Next(0, words.Count);
            sentence += words[randomIndex] + " ";
        }

        return sentence.Trim();
    }
}
