﻿using System;
using System.Linq;

class Program
{
    static void Main()
    {
        Console.WriteLine("Palindrome Detector");
        Console.WriteLine("Enter a sentence:");
        string sentence = Console.ReadLine();

        string[] words = sentence.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        string[] palindromeWords = GetPalindromeWords(words);

        if (palindromeWords.Length > 0)
        {
            Console.WriteLine("Palindromic words in the sentence:");
            foreach (string word in palindromeWords)
            {
                Console.WriteLine("\"" + word + "\"");
            }
        }
        else
        {
            Console.WriteLine("There are no palindromic words in the sentence.");
        }

        Console.ReadKey();
    }

    static string[] GetPalindromeWords(string[] words)
    {
        return words.Where(word => IsPalindrome(word)).ToArray();
    }

    static bool IsPalindrome(string word)
    {
        int left = 0;
        int right = word.Length - 1;

        while (left < right)
        {
            if (word[left] != word[right])
            {
                return false;
            }

            left++;
            right--;
        }

        return true;
    }
}
