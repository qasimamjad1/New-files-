﻿using System;
using System.Linq;

class Program
{
    static void Main()
    {
        Console.WriteLine("Longest and Shortest Word Finder");
        Console.WriteLine("Enter a sentence:");
        string sentence = Console.ReadLine();

        string[] words = sentence.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

        string[] longestWords = GetLongestWords(words);
        string[] shortestWords = GetShortestWords(words);

        Console.WriteLine("Longest word(s):");
        foreach (string word in longestWords)
        {
            Console.WriteLine("\"" + word + "\"");
        }

        Console.WriteLine("\nShortest word(s):");
        foreach (string word in shortestWords)
        {
            Console.WriteLine("\"" + word + "\"");
        }

        Console.ReadKey();
    }

    static string[] GetLongestWords(string[] words)
    {
        int maxLength = words.Max(w => w.Length);
        return words.Where(w => w.Length == maxLength).ToArray();
    }

    static string[] GetShortestWords(string[] words)
    {
        int minLength = words.Min(w => w.Length);
        return words.Where(w => w.Length == minLength).ToArray();
    }
}
