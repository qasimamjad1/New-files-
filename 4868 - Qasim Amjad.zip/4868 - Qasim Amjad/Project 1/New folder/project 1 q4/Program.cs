﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Word Search");
        Console.WriteLine("Enter a sentence:");
        string sentence = Console.ReadLine();

        Console.WriteLine("Enter a word to search:");
        string word = Console.ReadLine();

        int wordCount = CountWordOccurrences(sentence, word);

        if (wordCount > 0)
        {
            Console.WriteLine("The word \"" + word + "\" appears " + wordCount + " time(s) in the sentence.");
        }
        else
        {
            Console.WriteLine("The word \"" + word + "\" does not appear in the sentence.");
        }

        Console.ReadKey();
    }

    static int CountWordOccurrences(string sentence, string word)
    {
        int count = 0;
        int index = 0;

        while (index < sentence.Length)
        {
            index = sentence.IndexOf(word, index, StringComparison.OrdinalIgnoreCase);
            if (index == -1)
            {
                break;
            }

            count++;
            index += word.Length;
        }

        return count;
    }
}
