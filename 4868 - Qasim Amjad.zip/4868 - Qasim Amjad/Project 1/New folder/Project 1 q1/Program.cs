﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        Console.WriteLine("Word Frequency Analysis");
        Console.WriteLine("Enter a sentence:");
        string sentence = Console.ReadLine();//input string 

        Dictionary<string, int> wordFrequency = GetWordFrequency(sentence);

        Console.WriteLine("\nWord Frequency:");
        foreach (KeyValuePair<string, int> pair in wordFrequency)
        {
            Console.WriteLine("\"" + pair.Key + "\": " + pair.Value);
        }

        Console.ReadKey();
    }

    static Dictionary<string, int> GetWordFrequency(string sentence)
    {
        string[] words = sentence.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

        Dictionary<string, int> wordFrequency = new Dictionary<string, int>();

        foreach (string word in words)
        {
            if (wordFrequency.ContainsKey(word))
            {
                wordFrequency[word]++;
            }
            else
            {
                wordFrequency[word] = 1;
            }
        }

        return wordFrequency;
    }
}
