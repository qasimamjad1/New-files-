﻿using System;

namespace q20
{
    class Program
        {
            static void Main()
            {
                Console.Write("Enter first string: "); 
                string str_I = Console.ReadLine(); 
                Console.Write("Enter second string: ");
                string str_II = Console.ReadLine(); 
                int l_I = str_I.Length;
                int l_II = str_II.Length;
                int counter = 0; // counter to define the position for comparison of next letter
                for (int i = 0; i < l_I; i++) // targets each character of first string
                {
                    for (int j = counter; j < l_II; j++) // targets each character of second string
                    {
                        if (str_I[i] == str_II[j])
                        {
                            Console.Write(str_II[i]);
                            counter = j + 1;
                            break;
                        }
                    }
                }
                Console.ReadKey();
            }
        }
    }
