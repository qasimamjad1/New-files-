﻿using System;

namespace q14
{
    class Program
    {
        static void Main(string[] args)
        {
            int Height;
            Console.WriteLine("Enter the height of the triangle: ");
            Height = Convert.ToInt32(Console.ReadLine());
            

            for (int i = 1; i <= Height; i++)
            {
                for (int j = 1; j <= i; j++)
                {
                    Console.Write("* ");
                }
                Console.WriteLine();
            }

        }
    }//2n-1
}



