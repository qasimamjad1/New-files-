﻿using System;

namespace q5
{
    class Program
    {
        static void Main()
        {
            int a;
            for (a = 1; a <= 100; a++)
                if (a % 2 == 0)// if a have a remainder of 0 then it will be displayed , other wise if the remainder is 1 , it will not be displayed 
                    Console.WriteLine(a);
            Console.ReadKey();
        }
        
    }
}
