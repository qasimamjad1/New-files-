﻿using System;

namespace q7
{
    class Program
    {
        static void Main()
        {
            Console.Write("Enter the numberfor your table: ");
            int a = Convert.ToInt32(Console.ReadLine());
            
            for (int val = 1; val <= 12; val++)//limited to 12 starting from 1 
            {
              int   b = a * val;//another variable declared and ans is stored in it
                Console.WriteLine(b);
                ; 
            }
            Console.ReadKey();
        }
    }
}
