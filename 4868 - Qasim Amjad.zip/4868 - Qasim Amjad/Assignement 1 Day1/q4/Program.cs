﻿using System;

namespace q4
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("\nEnter the number to be squared : ");
            int a = Convert.ToInt32(Console.ReadLine());//input 

            int b;
            b = a * a;// the square is stored in b 
            Console.WriteLine( "\nSquared = {0}", b);//b displayed 
            Console.ReadKey();
        }
    }
}
