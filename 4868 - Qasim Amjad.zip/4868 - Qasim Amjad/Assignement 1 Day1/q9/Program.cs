﻿using System;

namespace q9
{
    class Program
    {
        static void Main(string[] args)
        {
            int f = 1 ;//f startng as 1

            Console.Write("Calculate the factorial of a given number:\n");

            Console.Write("Input the number Please : ");
            int num = Convert.ToInt32(Console.ReadLine());

            for ( int i = 1; i <= num; i++)
                f = f * i;

            Console.Write("The Factorial is: "+ f);
            Console.ReadKey();

        }


    }
}
