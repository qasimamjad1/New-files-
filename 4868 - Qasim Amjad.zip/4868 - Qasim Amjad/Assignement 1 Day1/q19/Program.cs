﻿using System;

namespace q19
{
    class Program
    {
        static void Main(string[] args)//see question 14 code is same 
        {
            int Height;
            
            Console.WriteLine("Enter the height of the triangle: ");
            Height = Convert.ToInt32(Console.ReadLine());


            for (int i = 1; i <= Height; i++)//nested loop 
            {
                for (int j = 1; j <= i; j++)
                {
                    Console.Write(j);
                    Console.Write("* ");
                }
                Console.WriteLine();
            }
        }
    }
}
