﻿using System;

namespace q10
{
    class Program
    {
        static void Main()//main function
        {
            Console.WriteLine("Enter the number of Terms:");
            int n = int.Parse(Console.ReadLine());

            Console.WriteLine("Fibonacci Sequence :  \n");
            for (int i = 0; i < n; i++)
            {
                Console.Write(Fibonacci(i) + " ");

            }

            Console.ReadLine();
            Console.ReadKey();//clearing and ending the output 
        }
        static int Fibonacci(int n)//fibonnaci function :The Fibonacci formula is given as, Fn = Fn-1 + Fn-2, where n > 1.
        {

            if (n <= 1)//if n <1 then nothing will be displayed 
                return n;

            int a = 0, b = 1, c = 0;
            for (int i = 2; i <= n; i++)
            {
                c = a + b;
                a = b;//updated a value 
                b = c;//and then b updated 
            }
            return b;//return the b value to the main function 

        }


    }
}
