﻿using System;

namespace q12
{
    class Program { 
  static void Main()
    {
        Console.WriteLine("Enter a string: ");
        string input = Console.ReadLine();

        bool isPalindrome = CheckPalindrome(input);//function called 

        if (isPalindrome)
        {
            Console.WriteLine("The string is a palindrome.");
        }
        else
        {
            Console.WriteLine("The string is not a palindrome.");
        }

        Console.ReadKey();
    }

    static bool CheckPalindrome(string str)
    {
            str = str.ToLower(); // Convert string to lowercase for case-insensitive comparison
            int left = 0;
        int right = str.Length - 1;

        while (left < right)
        {
            if (str[left] != str[right])
            {
                return false; // Characters at current positions do not match, not a palindrome
            }

            left++;
            right--;
        }

        return true; // All characters matched, it is a palindrome
    }
}}