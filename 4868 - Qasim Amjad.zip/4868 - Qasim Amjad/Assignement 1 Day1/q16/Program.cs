﻿using System;

namespace q16
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Enter a string: ");
            string input = Console.ReadLine();//input 

            string reversed = ReverseString(input);//function called 

            Console.WriteLine("Reversed string: " + reversed);

            Console.ReadKey();
        }

        static string ReverseString(string str)
        {
            char[] charArray = str.ToCharArray();
            Array.Reverse(charArray);//built in function for reversing of the string 
            return new string(charArray);
        }
    }
}
