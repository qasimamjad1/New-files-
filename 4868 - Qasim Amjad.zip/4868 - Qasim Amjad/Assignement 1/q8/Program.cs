﻿using System;

namespace q8
{
    class Program
    {
        static void Main(string[] args)
        {
            int num, i, x, max;


            Console.Write("Enter your number till you want to find the prime number : ");
            max = Convert.ToInt32(Console.ReadLine());
            

            for (num = 1; num <= max; num++)
            {
                x = 0;

                for (i = 2; i <= num / 2; i++)
                {
                    if (num % i == 0)
                    {
                        x++;
                        break;
                    }
                }

                if (x == 0 && num != 1)
                    Console.Write("{0} ", num);
            }
            Console.Write("\n");
            Console.ReadKey();
        }




    }
}
