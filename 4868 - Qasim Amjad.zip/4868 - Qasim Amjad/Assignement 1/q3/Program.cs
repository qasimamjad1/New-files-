﻿using System;

namespace q3
{
    class Program
    {
        static void Main()
        {
            int b=1;
            int [] A = { 3,5,9,6 };
            foreach (int i in A)
            {

                 b = A[i] * A[i + 1];

            }
            if ( b == 0)
            {
                Console.WriteLine(" 1 ");

            }
            else
            {
                Console.WriteLine(" -1 ");
            }
            Console.ReadKey();
        }
    }
}
